#ifndef FUNCTIONS_H
#define FUNCTIONS_H

void selectAction(int choice);
void codeCheckAm();
void codeCheckRu();
void codeCheckNu();

#endif // FUNCTIONS_H
